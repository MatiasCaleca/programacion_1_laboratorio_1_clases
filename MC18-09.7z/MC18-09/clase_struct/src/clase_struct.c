/*
 ============================================================================
 Name        : clase_struct.c
 Author      : Matias
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include<string.h>

struct direccion
{
	char calle[20];
	int numero;
};

struct datosPersonales
{
		char nombre[20];
		char apellido[20];
		char calle[20];
		struct direccion domicilio;
};


int main(void)
{
	struct datosPersonales vecAgenda[3];
	struct direccion vecDir[3];
	int i;

	for(i=0; i<3; i++)
	{
		printf("\Ingrese nombre: ");
		fgets(vecAgenda[i].nombre);
		printf("\Ingrese apellido: ");
		fgets(vecAgenda[i].apellido);
		printf("\Ingrese calle: ");
		fgets(vecAgenda[i].calle);

	}


}
