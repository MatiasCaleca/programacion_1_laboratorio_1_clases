/*
 ============================================================================
 Name        : clase_struct2.c
 Author      : Matias
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

// 1-Inicializar los empty
// 2-BuscarLibre(vector,tamaño,valor
// 3-hacer un menu (1-alta/2-baja/3-modificar/4-listar/5-ordenar

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "biblioteca.h"


int main(void)
{

}
