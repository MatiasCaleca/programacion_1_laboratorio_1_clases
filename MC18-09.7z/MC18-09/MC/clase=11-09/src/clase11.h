/*
 * clase11.h
 *
 *  Created on: 11 sep. 2019
 *      Author: alumno
 */

#ifndef CLASE11_H_
#define CLASE11_H_

int getArrayInt(int *pArray,char *pMensaje,char *pMensajeError,int minimo,int maximo,int reintentos, int limite);


#endif /* CLASE11_H_ */
