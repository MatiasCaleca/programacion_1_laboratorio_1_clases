/*
 ============================================================================
 Name        : clase=11-09.c
 Author      : MC
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#define CANT_EL 4

int main(void)
{
	int legajo[CANT_EL];
	char sexo[CANT_EL];
	int edad[CANT_EL];
	int nota1P[CANT_EL];
	int nota2P[CANT_EL];
	float promedio[CANT_EL];

	cargarSetDatos(legajo, sexo, edad, nota1P, nota2P, promedio);
	mostrarEstudiante(legajo, sexo, edad, nota1P, nota2P, promedio);
	mostrarEstudiantes(legajo, sexo, edad, nota1P, nota2P, promedio);
}

int cargarSetDatos(int *aLegajo, char *aSexo, int *aEdad, int *aNota1P, int *aNota2P, float *aPromedio, int limite)
{
	int i;
	int buffer;
	for(i=0;i<limite;i++)
	{
		if(getInt(&buffer, "Ingrese el legajo del alumno: ","Error.",1,100,2) == 0)
		{
			*aLegajo[i] = buffer;

		}else
		{
			*aLegajo[i] = 0;
		}
	}return 0;
}


int mostrarEstudiante(int aLegajo, char aSexo, int aEdad, int aNota1P, int aNota2P, float aPromedio)
{
	printf("\n%d  %c  %d  %d %d  %2.f", aLegajo, aSexo, aEdad, aNota1P, aNota2P, aPromedio );

	return 0;
}

int mostrarEstudiantes(int *aLegajo, char *aSexo, int *aEdad, int *aNota1P, int *aNota2P, float *aPromedio, int limite)
{
	int i;
	printf("\nlegajo, sexo, edad, nota1P, nota2P, prpmedio ");

	for(i=0;i<limite;i++)
		{
		mostrarEstudiante(aLegajo, aSexo, aEdad, aNota1P, aNota2P, aPromedio)
		}

	return 0;
}
