/*
 * utn_tp_laboratorio_1.h
 *
 *  Created on: 4 sep. 2019
 *      Author: Mati
 */

#include <stdio.h>
#include <stdlib.h>

#ifndef UTN_TP_LABORATORIO_1_H_
#define UTN_TP_LABORATORIO_1_H_

int menu();
int operacionSuma(float numeroA, float numeroB, float *pResultado);
int operacionResta(float numeroA, float numeroB, float *pResultado);
int operacionDivision(float numeroA, float numeroB, float *pResultado);
int operacionMultiplicacion(float numeroA, float numeroB, float *pResultado);
int operacionFactorial (float numero, float *pResultado);


#endif /* UTN_TP_LABORATORIO_1_H_ */
