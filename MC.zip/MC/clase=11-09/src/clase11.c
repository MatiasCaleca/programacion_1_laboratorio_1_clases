/*
 * clase11.c
 *
 *  Created on: 11 sep. 2019
 *      Author: alumno
 */

//Carga un array
#include <stdio.h>
#include <stdlib.h>
#include "clase11.h"



int getArrayInt(int *pArray,char *pMensaje,char *pMensajeError,int minimo,int maximo,int reintentos, int limite)
{
	int retorno = -1;
	int buffer;
	int i=0;
	char respuesta;
	printf("\nDEBUG\n");
	if(pArray != NULL && limite > 0)
	{
		do
		{
			if(	getInt(	&buffer, pMensaje, pMensajeError, minimo, maximo, reintentos) == 0)
			{
				pArray[i] = buffer;
				i++;
				if(i == limite)
				{
					break;
				}
			}

			printf("Continuar (s/n)? \n");
			fflush(stdin); // __fpurge(stdin)
			scanf("%c",&respuesta);
		}while(respuesta != 'n');
		retorno = i;
	}
	return retorno;
}

char getArrayChar(char *pArray, char *pMensaje,char *pMensajeError, char *sexoMasculino, char *sexoFemenino, int reintentos, int limite)
{

}
