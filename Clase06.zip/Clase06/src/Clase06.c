/*
 ============================================================================
 Name        : Clase06.c
 Author      : MCaleca
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int numero[10];
	int i;
	int suma;

	for(i=0; i<10; i++)
	{
		printf("\nIngrese un numero", i+1);
		scanf("%d", &numero[i]);
	}
	for(i=0;i<10; i++)
	{
		suma=suma+numero[i];
	}
	printf("\nLa suma de los numeros es: ", &suma);
}
