/*
 * biblioteca.h
 *
 *  Created on: 18 sep. 2019
 *      Author: alumno
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#ifndef BIBLIOTECA_H_
#define BIBLIOTECA_H_

struct datosPersonales
{
		char nombre[50];
		int edad;
		int dni;
		int isempty;
};

int menu();



#endif /* BIBLIOTECA_H_ */
