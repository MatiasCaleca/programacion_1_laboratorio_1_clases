/*
 * biblioteca.c
 *
 *  Created on: 18 sep. 2019
 *      Author: alumno
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "biblioteca.h"


int menu()
{
	int opcion;
	printf("\nMenu: \n ");
	printf("\n1- Alta: ");
	printf("\n2- Baja: ");
	printf("\n3- Modificar: ");
	printf("\n4- Listar: ");
	printf("\n5- Ordenar");
	scanf("%d", &opcion);
	return opcion;
}


