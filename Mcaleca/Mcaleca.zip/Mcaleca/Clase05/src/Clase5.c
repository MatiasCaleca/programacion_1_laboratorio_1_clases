 /*
 ============================================================================
 Name        : Clase5.c
 Author      : MCaleca
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdio_ext.h>
#include <stdlib.h>
#include "utn.h"


#define QTY_EDADES 5

int main(void)
{
	int edades[QTY_EDADES] = {100,200,300,400,500};

	getArrayInt(edades,QTY_EDADES,"Edad?\n","Error\n",0,200,2);
	printArrayInt(edades,QTY_EDADES);

	return EXIT_SUCCESS;
}










