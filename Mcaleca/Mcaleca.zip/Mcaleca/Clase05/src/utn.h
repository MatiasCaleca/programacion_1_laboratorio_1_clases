/*
 * utn.h
 *
 *  Created on: 4 sep. 2019
 *      Author: alumno
 */

#ifndef UTN_H_
#define UTN_H_

int initArrayInt(int *pArray , int limite, int valor);
int printArrayInt(int *pArray , int limite);
int getArrayInt(	int *pArray,
					int limite,
					char *pMensaje,
					char *pMensajeError,
					int minimo,
					int maximo,
					int reintentos);
int getInt(	int *pResultado,
			char *pMensaje,
			char *pMensajeError,
			int minimo,
			int maximo,
			int reintentos);


#endif /* UTN_H_ */
