/*
 ============================================================================
 Name        : clase06_bis.c
 Author      : MCaleca
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void)
{

int printNumeroMinimoMaximo(int*pArray, int limite, int i)
{
	int retorno = -1;
	int numeroMinimo;
	int numeroMaximo;
	if(pArray != NULL && limite >=0)
	{
		numeroMinimo = pArray [0];
		numeroMaximo = pArray [0];
		for(i=0;i<limite;i++)
		{
			if(pArray[i] < numeroMinimo)
			{
				numeroMinimo = pArray[i];
			}
			if(pArray[i] < numeroMaximo)
			{
				numeroMaximo = pArray[i];
			}
		}
		printf("\nEl numero Minimo:\n%i",numeroMinimo);
		printf("\nEl numero Maximo:\n%i",numeroMaximo);

		retorno = 0;
	}
	return retorno;
}

int printPromedio(int*pArray, int limite, int i)
{
	int retorno = -1;
	int acumulador = 0;
	int promedio;
	if(pArray != NULL && limite >=0)
	{
		for(i=0;i<limite;i++)
		{
			acumulador = acumulador + pArray[i];

		}
			promedio = acumulador / limite;
			printf("\nPromedio:\n%i", promedio);
			retorno = 0;
	}
	return retorno;
}

int printSuma(int *pArray, int limite, int i)
{
	int retorno = -1;
	int suma = 0;
	if(pArray != NULL)
	{
		for(i=0;i<limite;i++)
		{
			suma += pArray[i];

		}
		printf("\nSuma:\n%i",suma);
		retorno = 0;
	}
	return retorno;
}

int ordenar(int *pArray, int limite)
{
	int i;
	int flag;
	int flagEstaDesordenado;
	int aux;

	//validar
	while(flagEstaDesordenado == 1)
	{

	//pasadas
		flagEstaDesordenado = 0;
		for(i=0; i<(limite-1); i++)
		{
			if(pArray[i] > pArray[i+1])
			{
		// swap
				aux = pArray[i];
				pArray[i] = pArray[i+1];
				pArray[i] = aux;
				flagEstaDesordenado = 1;
			}
		}

	}

}
