/*
 * utn.h
 *
 *  Created on: 29 ago. 2019
 *      Author: profesor
 */

#ifndef UTN_H_
#define UTN_H_

int utn_getNumero(int* pNumero,int rangoMax,int rangoMin,
		  int reintentos,char* pMsg,char* pMsgErr);



#endif /* UTN_H_ */
